# SportsCart V2

A professional, production-ready **affiliate sports product comparison** website built with plain **HTML5, CSS3, and Vanilla JavaScript (ES6)** — no frameworks, no build step.

SportsCart aggregates sports products from trusted partner stores (Amazon, Flipkart, Decathlon, Nike, Adidas, Puma, Myntra, Ajio, Reliance Digital, Croma). It does not sell products directly — the *Visit Store* button redirects to the partner via an affiliate link.

## ✨ Features

- 🛒 Product browsing, filtering, sorting
- 🔍 Real-time live search (name / brand / category / store)
- ❤️ Favorites — saved in LocalStorage
- ⇄ Side-by-side product comparison (up to 4) with lowest-price highlight
- 🌙 Dark mode toggle (persistent)
- 🎞️ Auto-rotating hero slider
- 📱 Fully responsive (mobile, tablet, desktop, ultra-wide)
- ⚡ Lazy-loaded product images
- 🎨 Modern UI: glassmorphism navbar, soft shadows, rounded corners, Poppins
- ♿ Accessible markup, semantic HTML, ARIA labels

## 📁 Folder Structure

```
SportsCart/
├── index.html            Home (slider, categories, trending, deals, top rated, brands, stores, newsletter)
├── about.html
├── contact.html
├── privacy.html
├── terms.html
├── 404.html
│
├── pages/
│   ├── product.html      Product detail + related
│   ├── category.html     Filterable product listing
│   ├── compare.html      Compare table
│   ├── favorites.html
│   ├── search.html
│   ├── stores.html
│   └── deals.html
│
├── css/                  style, navbar, footer, cards, slider, category,
│                         compare, product, responsive, darkmode
├── js/                   app, utils, search, slider, favorites, compare,
│                         filter, darkmode, category, stores
├── data/                 products.js, categories.js, brands.js, stores.js, offers.js
├── images/               (logo, banners, categories, products, brands, stores, icons)
└── assets/               (fonts, videos, animations)
```

## 🚀 Installation

No build step required.

```bash
# Option 1 — just open the file
open index.html

# Option 2 — serve locally (recommended, so relative paths and search work cleanly)
npx serve .
# or
python3 -m http.server 8000
```

Then visit http://localhost:8000

## 🎨 Customization

All theme tokens live at the top of `css/style.css`:

```css
--primary:   #1565C0;
--secondary: #00BCD4;
--accent:    #FF9800;
--bg:        #F5F7FA;
```

Dark-mode overrides are in `css/darkmode.css`.

## ➕ How to Add a Product

Open `data/products.js` and append one object:

```js
{
  id: 19,
  name: "Nike Phantom GX",
  brand: "Nike",
  category: "football",      // must match a slug in data/categories.js
  price: 12999,
  oldPrice: 14999,           // optional — shows strikethrough
  rating: 4.7,
  reviews: 320,
  image: "https://.../photo.jpg",
  store: "Nike",             // must match a name in data/stores.js
  affiliateLink: "https://nike.com/...",
  description: "Precision football boot for playmakers.",
  deal: true,                // optional — shows DEAL badge & appears in Deals page
  trending: true             // optional — appears in Trending section
}
```

That's it — the new product automatically appears across the homepage, category, search, filters, deals (if `deal:true`), and is available for compare/favorites.

## 🛠️ How to Add a Category / Brand / Store

Edit `data/categories.js`, `data/brands.js`, or `data/stores.js` and push a new object. Used everywhere automatically.

## 🔮 Future Improvements

- Real backend / CMS (Strapi / Sanity) instead of static JS data
- Price-history charts on product pages
- "Notify me when price drops" via email
- PWA / offline support
- Server-side rendered SEO meta per product
- i18n (multi-language)

## 📄 License

MIT — free to use, modify, and ship.
